package ma.kasbi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ascenseur {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int numeroAscenseur;

	public Ascenseur() {
		super();
	}

	public int getNumeroAscenseur() {
		return numeroAscenseur;
	}

	public void setNumeroAscenseur(int numeroAscenseur) {
		this.numeroAscenseur = numeroAscenseur;
	}
	
	
	
	

}
