package ma.kasbi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Escalier {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int numeroEscalier ;

	public Escalier() {
		super();
	}

	public int getNumeroEscalier() {
		return numeroEscalier;
	}

	public void setNumeroEscalier(int numeroEscalier) {
		this.numeroEscalier = numeroEscalier;
	}
	
	
	

}
