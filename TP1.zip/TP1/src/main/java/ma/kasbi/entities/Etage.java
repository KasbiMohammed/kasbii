package ma.kasbi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Etage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int numeroEtage;

	public Etage() {
		super();
	}

	public int getNumeroEtage() {
		return numeroEtage;
	}

	public void setNumeroEtage(int numeroEtage) {
		this.numeroEtage = numeroEtage;
	}
	
	
	
	

}
