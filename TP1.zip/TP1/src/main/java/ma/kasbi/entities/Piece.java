package ma.kasbi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Piece {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int numeroPiece;
   private int nbrOccupants;
   private int nbrFenetres;
public Piece() {
	super();
}
public int getNbrOccupants() {
	return nbrOccupants;
}
public void setNbrOccupants(int nbrOccupants) {
	this.nbrOccupants = nbrOccupants;
}
public int getNbrFenetres() {
	return nbrFenetres;
}
public void setNbrFenetres(int nbrFenetres) {
	this.nbrFenetres = nbrFenetres;
}
public int getNumeroPiece() {
	return numeroPiece;
}
public void setNumeroPiece(int numeroPiece) {
	this.numeroPiece = numeroPiece;
}
   
   
   
}
