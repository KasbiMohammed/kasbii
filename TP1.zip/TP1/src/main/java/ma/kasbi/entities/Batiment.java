package ma.kasbi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Batiment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int numeroBatiment;
	private String adresse;
	
	
	
	
	public Batiment() {
		super();
	}
	public int getNumeroBatiment() {
		return numeroBatiment;
	}
	public void setNumeroBatiment(int numeroBatiment) {
		this.numeroBatiment = numeroBatiment;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	

}
