package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Etage;
import ma.kasbi.service.EtageService;

@RestController
@RequestMapping("/api/v1/Etages")
public class EtageController {

	@Autowired
	private EtageService service;

	@GetMapping
	public List<Etage> findAllEtage() {
		return service.findAll();
	}

	@PostMapping
	public Etage createEtage(@RequestBody Etage Etage) {
		Etage.setNumeroEtage(0);
		return service.create(Etage);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Etage Etage = service.findById(id);
		if (Etage == null) {
			return new ResponseEntity<Object>("Etage avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Etage);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updateEtage(@PathVariable int id, @RequestBody Etage newEtage) {
		Etage oldEtage = service.findById(id);
		if (oldEtage == null) {
			return new ResponseEntity<Object>("Etage avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newEtage.setNumeroEtage(id);
			return ResponseEntity.ok(service.update(newEtage));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteEtage(@PathVariable int id) {
		Etage Etage = service.findById(id);
		if (Etage == null) {
			return new ResponseEntity<Object>("Etage avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Etage);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}

