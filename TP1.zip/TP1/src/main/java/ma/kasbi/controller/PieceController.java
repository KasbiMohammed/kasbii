package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Piece;
import ma.kasbi.service.PieceService;

@RestController
@RequestMapping("/api/v1/Pieces")
public class PieceController {

	@Autowired
	private PieceService service;

	@GetMapping
	public List<Piece> findAllPiece() {
		return service.findAll();
	}

	@PostMapping
	public Piece createPiece(@RequestBody Piece Piece) {
		Piece.setNumeroPiece(0);
		return service.create(Piece);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Piece Piece = service.findById(id);
		if (Piece == null) {
			return new ResponseEntity<Object>("Piece avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Piece);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updatePiece(@PathVariable int id, @RequestBody Piece newPiece) {
		Piece oldPiece = service.findById(id);
		if (oldPiece == null) {
			return new ResponseEntity<Object>("Piece avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newPiece.setNumeroPiece(id);
			return ResponseEntity.ok(service.update(newPiece));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deletePiece(@PathVariable int id) {
		Piece Piece = service.findById(id);
		if (Piece == null) {
			return new ResponseEntity<Object>("Piece avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Piece);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}
