package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Porte;
import ma.kasbi.service.PorteService;

@RestController
@RequestMapping("/api/v1/Portes")
public class PorteController {

	@Autowired
	private PorteService service;

	@GetMapping
	public List<Porte> findAllPorte() {
		return service.findAll();
	}

	@PostMapping
	public Porte createPorte(@RequestBody Porte Porte) {
		Porte.setNumeroPorte(0);
		return service.create(Porte);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Porte Porte = service.findById(id);
		if (Porte == null) {
			return new ResponseEntity<Object>("Porte avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Porte);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updatePorte(@PathVariable int id, @RequestBody Porte newPorte) {
		Porte oldPorte = service.findById(id);
		if (oldPorte == null) {
			return new ResponseEntity<Object>("Porte avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newPorte.setNumeroPorte(id);
			return ResponseEntity.ok(service.update(newPorte));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deletePorte(@PathVariable int id) {
		Porte Porte = service.findById(id);
		if (Porte == null) {
			return new ResponseEntity<Object>("Porte avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Porte);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}

