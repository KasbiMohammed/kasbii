package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Escalier;
import ma.kasbi.service.EscalierService;

@RestController
@RequestMapping("/api/v1/Escaliers")
public class EscalierController {

	@Autowired
	private EscalierService service;

	@GetMapping
	public List<Escalier> findAllEscalier() {
		return service.findAll();
	}

	@PostMapping
	public Escalier createEscalier(@RequestBody Escalier Escalier) {
		Escalier.setNumeroEscalier(0);
		return service.create(Escalier);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Escalier Escalier = service.findById(id);
		if (Escalier == null) {
			return new ResponseEntity<Object>("Escalier avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Escalier);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updateEscalier(@PathVariable int id, @RequestBody Escalier newEscalier) {
		Escalier oldEscalier = service.findById(id);
		if (oldEscalier == null) {
			return new ResponseEntity<Object>("Escalier avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newEscalier.setNumeroEscalier(id);
			return ResponseEntity.ok(service.update(newEscalier));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteEscalier(@PathVariable int id) {
		Escalier Escalier = service.findById(id);
		if (Escalier == null) {
			return new ResponseEntity<Object>("Escalier avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Escalier);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}

