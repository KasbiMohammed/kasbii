package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Batiment;
import ma.kasbi.service.BatimentService;

@RestController
@RequestMapping("/api/v1/Batiments")
public class BatimentController {

	@Autowired
	private BatimentService service;

	@GetMapping
	public List<Batiment> findAllBatiment() {
		return service.findAll();
	}

	@PostMapping
	public Batiment createBatiment(@RequestBody Batiment Batiment) {
		Batiment.setNumeroBatiment(0);
		return service.create(Batiment);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Batiment Batiment = service.findById(id);
		if (Batiment == null) {
			return new ResponseEntity<Object>("Batiment avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Batiment);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updateBatiment(@PathVariable int id, @RequestBody Batiment newBatiment) {
		Batiment oldBatiment = service.findById(id);
		if (oldBatiment == null) {
			return new ResponseEntity<Object>("Batiment avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newBatiment.setNumeroBatiment(id);
			return ResponseEntity.ok(service.update(newBatiment));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteBatiment(@PathVariable int id) {
		Batiment Batiment = service.findById(id);
		if (Batiment == null) {
			return new ResponseEntity<Object>("Batiment avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Batiment);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}
