package ma.kasbi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ma.kasbi.entities.Ascenseur;
import ma.kasbi.service.AscenseurService;

@RestController
@RequestMapping("/api/v1/Ascenseurs")
public class AscenseurController {

	@Autowired
	private AscenseurService service;

	@GetMapping
	public List<Ascenseur> findAllAscenseur() {
		return service.findAll();
	}

	@PostMapping
	public Ascenseur createAscenseur(@RequestBody Ascenseur Ascenseur) {
		Ascenseur.setNumeroAscenseur(0);
		return service.create(Ascenseur);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Ascenseur Ascenseur = service.findById(id);
		if (Ascenseur == null) {
			return new ResponseEntity<Object>("Ascenseur avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			return ResponseEntity.ok(Ascenseur);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> updateAscenseur(@PathVariable int id, @RequestBody Ascenseur newAscenseur) {
		Ascenseur oldAscenseur = service.findById(id);
		if (oldAscenseur == null) {
			return new ResponseEntity<Object>("Ascenseur avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			newAscenseur.setNumeroAscenseur(id);
			return ResponseEntity.ok(service.update(newAscenseur));
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteAscenseur(@PathVariable int id) {
		Ascenseur Ascenseur = service.findById(id);
		if (Ascenseur == null) {
			return new ResponseEntity<Object>("Ascenseur avec ID = " + id + " n'existe pas", HttpStatus.BAD_REQUEST);
		} else {
			service.delete(Ascenseur);
			return ResponseEntity.ok("filière supprimée");
		}
	}
	
}
