package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Ascenseur;
import ma.kasbi.repository.AscenseurRepository;

@Service
public class AscenseurService implements IDao<Ascenseur> {

	@Autowired
	private AscenseurRepository repository;

	@Override
	public Ascenseur create(Ascenseur o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Ascenseur o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Ascenseur update(Ascenseur o) {
		return repository.save(o);
	}

	@Override
	public Ascenseur findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Ascenseur> findAll() {
		return repository.findAll();
	}
	
	

}
