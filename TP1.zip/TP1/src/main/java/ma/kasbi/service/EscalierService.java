package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Escalier;
import ma.kasbi.repository.EscalierRepository;

@Service
public class EscalierService implements IDao<Escalier> {

	@Autowired
	private EscalierRepository repository;

	@Override
	public Escalier create(Escalier o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Escalier o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Escalier update(Escalier o) {
		return repository.save(o);
	}

	@Override
	public Escalier findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Escalier> findAll() {
		return repository.findAll();
	}
	
	

}
