package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Piece;
import ma.kasbi.repository.PieceRepository;

@Service
public class PieceService implements IDao<Piece> {

	@Autowired
	private PieceRepository repository;

	@Override
	public Piece create(Piece o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Piece o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Piece update(Piece o) {
		return repository.save(o);
	}

	@Override
	public Piece findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Piece> findAll() {
		return repository.findAll();
	}
	
	

}
