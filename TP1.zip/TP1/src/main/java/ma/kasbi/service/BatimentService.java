package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Batiment;
import ma.kasbi.repository.BatimentRepository;

@Service
public class BatimentService implements IDao<Batiment> {

	@Autowired
	private BatimentRepository repository;

	@Override
	public Batiment create(Batiment o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Batiment o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Batiment update(Batiment o) {
		return repository.save(o);
	}

	@Override
	public Batiment findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Batiment> findAll() {
		return repository.findAll();
	}
	
	

}
