package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Etage;
import ma.kasbi.repository.EtageRepository;

@Service
public class EtageService implements IDao<Etage> {

	@Autowired
	private EtageRepository repository;

	@Override
	public Etage create(Etage o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Etage o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Etage update(Etage o) {
		return repository.save(o);
	}

	@Override
	public Etage findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Etage> findAll() {
		return repository.findAll();
	}
	
	

}
