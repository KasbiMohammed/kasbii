package ma.kasbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ma.kasbi.dao.IDao;
import ma.kasbi.entities.Porte;
import ma.kasbi.repository.PorteRepository;

@Service
public class PorteService implements IDao<Porte> {

	@Autowired
	private PorteRepository repository;

	@Override
	public Porte create(Porte o) {
		return repository.save(o);
	}

	@Override
	public boolean delete(Porte o) {
		try {
			repository.delete(o);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Porte update(Porte o) {
		return repository.save(o);
	}

	@Override
	public Porte findById(int id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public List<Porte> findAll() {
		return repository.findAll();
	}
	
	

}
